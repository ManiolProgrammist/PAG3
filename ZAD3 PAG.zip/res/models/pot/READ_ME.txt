NOT FOR COMMERCIAL USE

*   *   *   *   *

House Plant 02
eb_house_plant_02

House Plant 02 made to be used within Unreal. Materials PBR compliant. Great for use in a game or architectural render. For more details or questions feel free to contact me. 

DETAILS:
- Tri Count: 438
- Color Map: eb_house_plant_02_c
- Roughness Map: Packed in RED channel of eb_house_plant_02_g
- Metal Map: Packed in GREEN channel of eb_house_plant_02_g
- Opacity Mask: Packed in BLUE channel of eb_house_plant_02_g
- Normal Map: eb_house_plant_02_n

*   *   *   *   *

For questions contact Ernesto at ernestbezera@gmail.com